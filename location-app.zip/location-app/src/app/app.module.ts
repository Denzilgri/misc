import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';

import { AppComponent } from './app.component';
import { ContainerComponent } from './container/container.component';
import { CitySearchComponent } from './city-search/city-search.component';
import { CitySearchResultComponent } from './city-search-result/city-search-result.component';

@NgModule({
  declarations: [
    AppComponent,
    ContainerComponent,
    CitySearchComponent,
    CitySearchResultComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
