import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { LocationService } from '../location.service';


@Component({
  selector: 'city-search-result',
  templateUrl: './city-search-result.component.html',
  styleUrls: ['./city-search-result.component.css']
})
export class CitySearchResultComponent implements OnInit {

  private subscription: Subscription;
  location: any = {};

  constructor(private locationService: LocationService) {
    this.subscription = this.locationService.getState().subscribe(
      state => {
        this.location = state;
      });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
