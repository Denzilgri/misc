import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { LocationService } from '../location.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'city-search',
  templateUrl: './city-search.component.html',
  styleUrls: ['./city-search.component.css']
})
export class CitySearchComponent implements OnInit {

  constructor(private locationService: LocationService) { }

  ngOnInit() {
  }

  onSubmit(cityNameForm: NgForm) {
    const cityName = cityNameForm.value.cityName;
    let locationStore: any = {};
    let obj = this.locationService.getLocation(cityName);

    if (obj instanceof Observable) {
      obj.subscribe((location) => {
        this.setLocation({ lat: location.lat, lng: location.lng }, cityName, locationStore);
      });
    } else {
      this.setLocation(obj, cityName, locationStore);
    }

  }

  setLocation(location: any, cityName: string, locationStore: any) {
    this.locationService.setState(location, cityName);
    if (!localStorage.getItem('locationStore')) {
      localStorage.setItem('locationStore', '');
    } else {
      locationStore = JSON.parse(localStorage.getItem('locationStore'));
    }

    locationStore[cityName] = location;
    localStorage.setItem('locationStore', JSON.stringify(locationStore));
  }

}
