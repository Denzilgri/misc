import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  private url = 'http://localhost:3000/';  // URL to web api

  constructor(private http: HttpClient) { }

  getLocation (city: string): Observable<any> {

    const locationStore: any = JSON.parse(localStorage.getItem('locationStore'));

    if (locationStore && locationStore[city]) {
      return locationStore[city];
    } else {
      const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
      return this.http.post<any>(this.url, {city: city}, {responseType: 'json', headers});
    }
  }

  private state = new Subject<any>();

  setState(location: any, city: string) {
    this.state.next(location);
  }

  getState(): Observable<any> {
    return this.state.asObservable();
  }
}
