const express = require('express');
const app = express();
const port = 3000;
const http = require('http');


app.listen(port, () => console.log(`Location app listening on port ${port}!`));

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

app.post('/', function (req, res, next) {
    // Handle the get for this route
    console.log('its called', req.body);
    // http://www.datasciencetoolkit.org/maps/api/geocode/json?sensor=false&address=

    callAPI(req.body.city, res);
});

function callAPI(city, res) {
    http.get(`http://www.datasciencetoolkit.org/maps/api/geocode/json?sensor=false&address=${city}`,
        (incomingMsg) => {
            incomingMsg.setEncoding('utf-8')
            incomingMsg.on('data', function (data) {
                const location = JSON.parse(data).results[0].geometry.location;
                // sendResponse(location);
                res.set('Content-Type', 'application/json');
                res.send(location);
            });
        }).on('error', function (e) {
            console.log("Got error: " + e.message);
        });
}